"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [466], {
        7888: function(A, e, t) {
            t.d(e, {
                u: function() {
                    return s
                },
                VP: function() {
                    return l
                },
                QG: function() {
                    return o
                }
            });
            var r = t(7437);
            t(2265);
            let s = A => {
                    let {
                        size: e = 24,
                        className: t
                    } = A;
                    return (0, r.jsxs)("svg", {
                        width: e,
                        height: e,
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        className: t,
                        children: [(0, r.jsx)("path", {
                            opacity: "0.4",
                            d: "M15.5 13.15H13.33C11.55 13.15 10.1 11.71 10.1 9.92V7.75C10.1 7.34 9.77 7 9.35 7H6.18C3.87 7 2 8.5 2 11.18V17.82C2 20.5 3.87 22 6.18 22H12.07C14.38 22 16.25 20.5 16.25 17.82V13.9C16.25 13.48 15.91 13.15 15.5 13.15Z",
                            fill: "currentColor"
                        }), (0, r.jsx)("path", {
                            d: "M17.82 2H15.85H14.76H11.93C9.67001 2 7.84001 3.44 7.76001 6.01C7.82001 6.01 7.87001 6 7.93001 6H10.76H11.85H13.82C16.13 6 18 7.5 18 10.18V12.15V14.86V16.83C18 16.89 17.99 16.94 17.99 16.99C20.22 16.92 22 15.44 22 12.83V10.86V8.15V6.18C22 3.5 20.13 2 17.82 2Z",
                            fill: "currentColor"
                        }), (0, r.jsx)("path", {
                            d: "M11.98 7.15C11.67 6.84 11.14 7.05 11.14 7.48V10.1C11.14 11.2 12.07 12.1 13.21 12.1C13.92 12.11 14.91 12.11 15.76 12.11C16.19 12.11 16.41 11.61 16.11 11.31C15.02 10.22 13.08 8.27 11.98 7.15Z",
                            fill: "currentColor"
                        })]
                    })
                },
                l = A => {
                    let {
                        size: e = 24,
                        className: t
                    } = A;
                    return (0, r.jsxs)("svg", {
                        width: e,
                        height: e,
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        className: t,
                        children: [(0, r.jsx)("path", {
                            opacity: "0.4",
                            d: "M18 3H6C3.79 3 2 4.78 2 6.97V17.03C2 19.22 3.79 21 6 21H18C20.21 21 22 19.22 22 17.03V6.97C22 4.78 20.21 3 18 3Z",
                            fill: "currentColor"
                        }), (0, r.jsx)("path", {
                            d: "M19 8.75H14C13.59 8.75 13.25 8.41 13.25 8C13.25 7.59 13.59 7.25 14 7.25H19C19.41 7.25 19.75 7.59 19.75 8C19.75 8.41 19.41 8.75 19 8.75Z",
                            fill: "currentColor"
                        }), (0, r.jsx)("path", {
                            d: "M19 12.75H15C14.59 12.75 14.25 12.41 14.25 12C14.25 11.59 14.59 11.25 15 11.25H19C19.41 11.25 19.75 11.59 19.75 12C19.75 12.41 19.41 12.75 19 12.75Z",
                            fill: "currentColor"
                        }), (0, r.jsx)("path", {
                            d: "M19 16.75H17C16.59 16.75 16.25 16.41 16.25 16C16.25 15.59 16.59 15.25 17 15.25H19C19.41 15.25 19.75 15.59 19.75 16C19.75 16.41 19.41 16.75 19 16.75Z",
                            fill: "currentColor"
                        }), (0, r.jsx)("path", {
                            d: "M8.49945 11.7899C9.77523 11.7899 10.8095 10.7557 10.8095 9.47992C10.8095 8.20414 9.77523 7.16992 8.49945 7.16992C7.22368 7.16992 6.18945 8.20414 6.18945 9.47992C6.18945 10.7557 7.22368 11.7899 8.49945 11.7899Z",
                            fill: "currentColor"
                        }), (0, r.jsx)("path", {
                            d: "M9.29954 13.1098C8.76954 13.0598 8.21954 13.0598 7.68954 13.1098C6.00954 13.2698 4.65954 14.5998 4.49954 16.2798C4.48954 16.4198 4.52954 16.5598 4.62954 16.6598C4.72954 16.7598 4.85954 16.8298 4.99954 16.8298H11.9995C12.1395 16.8298 12.2795 16.7698 12.3695 16.6698C12.4595 16.5698 12.5095 16.4298 12.4995 16.2898C12.3295 14.5998 10.9895 13.2698 9.29954 13.1098Z",
                            fill: "currentColor"
                        })]
                    })
                },
                o = A => {
                    let {
                        size: e = 24,
                        className: t
                    } = A;
                    return (0, r.jsxs)("svg", {
                        width: e,
                        height: e,
                        viewBox: "0 0 32 32",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        className: t,
                        children: [(0, r.jsx)("path", {
                            opacity: "0.4",
                            d: "M22.6667 27.3333H9.33335C5.33335 27.3333 2.66669 25.3333 2.66669 20.6667V11.3333C2.66669 6.66666 5.33335 4.66666 9.33335 4.66666H22.6667C26.6667 4.66666 29.3334 6.66666 29.3334 11.3333V20.6667C29.3334 25.3333 26.6667 27.3333 22.6667 27.3333Z",
                            fill: "currentColor"
                        }), (0, r.jsx)("path", {
                            d: "M16 17.16C14.88 17.16 13.7467 16.8133 12.88 16.1067L8.70665 12.7733C8.27999 12.4267 8.19999 11.8 8.54666 11.3733C8.89333 10.9467 9.52 10.8667 9.94666 11.2133L14.12 14.5467C15.1333 15.36 16.8533 15.36 17.8666 14.5467L22.04 11.2133C22.4667 10.8667 23.1067 10.9333 23.44 11.3733C23.7867 11.8 23.72 12.44 23.28 12.7733L19.1067 16.1067C18.2533 16.8133 17.12 17.16 16 17.16Z",
                            fill: "currentColor"
                        })]
                    })
                }
        },
        7908: function(A, e, t) {
            t.r(e), t.d(e, {
                LinkItem: function() {
                    return h
                }
            });
            var r = t(7437),
                s = t(348),
                l = t(6691),
                o = t.n(l),
                n = t(4033),
                i = t(7415),
                a = t(7888),
                C = t(2265);
            let c = () => {
                    let [A, e] = (0, C.useState)(null), t = async A => {
                        var t;
                        if (!(null === (t = navigator) || void 0 === t ? void 0 : t.clipboard)) return i.toast.warn("Clipboard not supported"), !1;
                        try {
                            return await navigator.clipboard.writeText(A), e(A), !0
                        } catch (A) {
                            return console.warn("Copy failed", A), e(null), !1
                        }
                    };
                    return [A, t]
                },
                d = A => {
                    let {
                        title: e,
                        children: t,
                        onClick: s
                    } = A;
                    return (0, r.jsx)("button", {
                        onClick: s,
                        "aria-label": e,
                        className: "text-slate-500 transition-all hover:text-slate-400",
                        children: t
                    })
                },
                h = A => {
                    let {
                        icon: e,
                        name: t,
                        description: l = "",
                        href: C = "",
                        canCopy: h = !1
                    } = A, u = (0, n.useRouter)(), [, E] = c(), x = A => {
                        if (A && A.stopPropagation(), !h) return;
                        let e = C || l;
                        e && E(e).then(A => {
                            A ? i.toast.success("Copied") : i.toast.error("Failed to copy")
                        })
                    }, g = A => {
                        if (A && A.stopPropagation(), C) {
                            if (C.startsWith("http")) {
                                window.open(C, "_blank", "noopener noreferrer");
                                return
                            }
                            u.push(C, {
                                scroll: !1
                            })
                        }
                    }, w = () => {
                        if (C) {
                            g();
                            return
                        }
                        if (h) {
                            x();
                            return
                        }
                    };
                    return (0, r.jsxs)("div", {
                        role: "link",
                        tabIndex: 0,
                        className: (0, s.Z)("flex cursor-pointer items-center space-x-4 rounded-xl p-4", "border border-slate-700 bg-slate-800", "transition-all hover:border-blue-500", "select-none"),
                        onClick: w,
                        onKeyDown: w,
                        children: [(0, r.jsx)(o(), {
                            src: e,
                            alt: t,
                            width: 48,
                            height: 48,
                            quality: 100,
                            className: "rounded-xl shadow-md"
                        }), (0, r.jsxs)("div", {
                            className: "flex-1",
                            children: [(0, r.jsx)("h3", {
                                className: "font-semibold",
                                children: t
                            }), l && (0, r.jsx)("p", {
                                className: "text-slate-400",
                                children: l
                            })]
                        }), h && (0, r.jsx)(d, {
                            title: "Copy",
                            onClick: x,
                            children: (0, r.jsx)(a.u, {
                                size: 24
                            })
                        })]
                    })
                }
        },
        8502: function(A, e, t) {
            t.r(e), t.d(e, {
                QuickActions: function() {
                    return i
                }
            });
            var r = t(7437),
                s = t(348),
                l = t(1095),
                o = t(7888);
            let n = A => {
                    let {
                        icon: e,
                        name: t,
                        onClick: l
                    } = A;
                    return (0, r.jsxs)("button", {
                        type: "button",
                        className: (0, s.Z)("flex items-center justify-center space-x-2 rounded-lg px-4 py-2 ", "bg-slate-700 text-white", "transition-colors", "select-none", "group hover:bg-blue-600"),
                        onClick: l,
                        children: [(0, r.jsx)("i", {
                            className: "text-slate-400 transition-colors group-hover:text-blue-200",
                            children: e
                        }), (0, r.jsx)("span", {
                            className: "font-medium",
                            children: t
                        })]
                    })
                },
                i = A => {
                    let {
                        mailLink: e,
                        vCardLink: t
                    } = A, i = A => () => {
                        "EMAIL" === A && window.open(e, l.tq ? "_self" : "_blank"), "ADD_CONTACT" === A && window.open(t, "_self")
                    };
                    return (0, r.jsxs)("div", {
                        className: (0, s.Z)("sticky bottom-1 z-10", "grid grid-cols-2 gap-2 rounded-xl p-2", "border border-slate-700 bg-slate-800/80 backdrop-blur-md", "shadow-[0_0_8px_4px_rgba(0,0,0,0.25)]"),
                        children: [(0, r.jsx)(n, {
                            icon: (0, r.jsx)(o.QG, {
                                size: 24
                            }),
                            name: "Send Email",
                            onClick: i("EMAIL")
                        }), (0, r.jsx)(n, {
                            icon: (0, r.jsx)(o.VP, {
                                size: 24
                            }),
                            name: "Save Contact",
                            onClick: i("ADD_CONTACT")
                        })]
                    })
                }
        },
        6693: function(A, e, t) {
            t.r(e), e.default = {
                src: "/_next/static/media/ncdai-avatar.34d5aa1a.jpeg",
                height: 512,
                width: 512,
                blurDataURL: "data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wgARCAAIAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAP/xAAUAQEAAAAAAAAAAAAAAAAAAAAC/9oADAMBAAIQAxAAAAGoC//EABcQAAMBAAAAAAAAAAAAAAAAAAECAwT/2gAIAQEAAQUCrqE3/8QAFREBAQAAAAAAAAAAAAAAAAAAAAH/2gAIAQMBAT8Br//EABURAQEAAAAAAAAAAAAAAAAAAAAB/9oACAECAQE/AY//xAAYEAACAwAAAAAAAAAAAAAAAAAAEQESUv/aAAgBAQAGPwJ3lZP/xAAXEAEBAQEAAAAAAAAAAAAAAAABEQAx/9oACAEBAAE/IbLc8BXf/9oADAMBAAIAAwAAABAP/8QAFhEAAwAAAAAAAAAAAAAAAAAAAAEh/9oACAEDAQE/EHp//8QAFhEAAwAAAAAAAAAAAAAAAAAAAAEh/9oACAECAQE/EEh//8QAGxAAAgEFAAAAAAAAAAAAAAAAAREhADFBYXH/2gAIAQEAAT8QLSiAehaviDOuV//Z",
                blurWidth: 8,
                blurHeight: 8
            }
        },
        6077: function(A, e, t) {
            t.r(e), e.default = {
                src: "/_next/static/media/ncdai-cover-lossy.d5a87980.webp",
                height: 600,
                width: 1200,
                blurDataURL: "data:image/webp;base64,UklGRi4AAABXRUJQVlA4ICIAAABwAQCdASoIAAQAAkA4JZQCdAFAAAD++pqF1ZHJN2G+4IAA",
                blurWidth: 8,
                blurHeight: 4
            }
        },
        5143: function(A, e, t) {
            t.r(e), e.default = {
                src: "/_next/static/media/ncdai-momo-qr-code.f27e538e.jpeg",
                height: 1280,
                width: 755,
                blurDataURL: "data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wgARCAAIAAUDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAX/xAAUAQEAAAAAAAAAAAAAAAAAAAAB/9oADAMBAAIQAxAAAAG8F//EABcQAAMBAAAAAAAAAAAAAAAAAAABAgP/2gAIAQEAAQUCWNH/xAAWEQADAAAAAAAAAAAAAAAAAAAAARL/2gAIAQMBAT8Btn//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AX//xAAWEAADAAAAAAAAAAAAAAAAAAAAAUH/2gAIAQEABj8CdP/EABgQAQEAAwAAAAAAAAAAAAAAABEBADFB/9oACAEBAAE/IWqxc0Z//9oADAMBAAIAAwAAABAP/8QAFREBAQAAAAAAAAAAAAAAAAAAAQD/2gAIAQMBAT8QAv/EABURAQEAAAAAAAAAAAAAAAAAAAAR/9oACAECAQE/EK//xAAZEAEAAgMAAAAAAAAAAAAAAAABABEhYXH/2gAIAQEAAT8QKlowg47n/9k=",
                blurWidth: 5,
                blurHeight: 8
            }
        }
    }
]);